idk how licesnse or gitignore works :')
sth sth this is description ig
